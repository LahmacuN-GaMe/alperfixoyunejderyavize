﻿using System;
using System.Threading;

namespace den
{
    class Program
    {
        // --- HAFTA 4: DEGISKENLER VE TIPLER (int, float, double, string, bool) ---
        static string oyuncuAdi = "Ejder Avcisi";
        static int can = 100;
        static int maksCan = 100;
        static int altin = 25;
        static int iksirSayisi = 2;
        static int mevcutKat = 1;
        static string bolumAdi = "Karanlik Mahzen";
        static int sevilenHayvan = 0;
        static bool failSafeAktif = true;
        static bool ejderhaIleAnlasildi = false;

        // Tema Rengi (Katlara gore dinamik degisir)
        static ConsoleColor temaRengi = ConsoleColor.DarkCyan;

        // Silah Durumu (Siradan, Nadir, Efsanevi, Mistik)
        static string silahAdi = "Ciplak Yumruk";
        static string silahNadirlik = "Siradan";
        static int silahMinHasar = 6;
        static int silahMaxHasar = 10;
        static float kritikCarpan = 1.5f;

        // Kostum Durumu ve Envanter Kayitlari (Pasif Ozellikler)
        static string kostumAdi = "Yirtik Mahkum Cuvali";
        static int kostumTurBasiCan = 0;
        static int kostumEkstraHasar = 0;
        static bool sifaciYelekVar = false;
        static bool celikZirhVar = false;
        static bool kurtPeleriniVar = false;
        static bool ejderZirhiVar = false;

        // 5 Yardimci Karakter
        static bool sadikKatildi = false;
        static bool nehirKatildi = false;
        static bool emreKatildi = false;
        static bool denizKatildi = false;
        static bool alperenKatildi = false;

        // 3 Mistik Silah Kontrolu
        static bool mistik1Dustu = false;
        static bool mistik2Dustu = false;
        static bool mistik3Dustu = false;

        static readonly Random rnd = new Random();

        static void Main()
        {
            try { Console.Title = "ALPER.EXE PRESENTS: KADIM EJDERHA"; } catch { }
            SinematikGirisEkrani();

            // --- HAFTA 7: SAYACLI FOR DONGUSU (25 KATLI EJDERHA ZINDANI) ---
            for (mevcutKat = 1; mevcutKat <= 25; mevcutKat++)
            {
                if (can <= 0)
                {
                    break; // Hafta 6: Olum durumunda ana donguden cikis
                }

                TemaGuncelle(mevcutKat);
                BolumYoneticisi(mevcutKat);

                if (ejderhaIleAnlasildi)
                {
                    break; // Hafta 6: Kadim anlasma saglanirsa donguyu sonlandir
                }
            }

            if (can > 0)
            {
                OyunSonuEkrani();
            }
            else
            {
                OlumEkrani();
            }
        }

        // --- SINEMATIK GIRIS & EJDERHA SEMBOLU ---
        static void SinematikGirisEkrani()
        {
            EkranTemizle();
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("==========================================================================");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("                 [ SİSTEM BAŞLATILIYOR: ALPER.EXE v2.6 ]                  ");
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("==========================================================================\n");
            Console.ResetColor();
            Thread.Sleep(400);

            YavasYaz("  > Karanlik derinliklerde kadim muhurler kiriliyor...", ConsoleColor.Gray, 18);
            YavasYaz("  > Yeraltinin 25 kat altindan lav kokusu ve kanat sesleri yukseliyor...", ConsoleColor.DarkYellow, 18);
            Thread.Sleep(350);

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"
                      \||/
                      |  @___oo
            /\  /\   / (__,,,,|
           ) /^\) ^\/ _)
           )   /^\/   _)
           )   _ /  / _)
       /\  )/\/ ||  | )_)
      <  >      |(,,) )__)
       ||      /    \)___)\
       | \____(      )___) )___
        \______(_______;;; __;;;
            ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("  ╔════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("  ║            ALPER.EXE PRESENTS :  K A D İ M   E J D E R H A         ║");
            Console.WriteLine("  ║                 25 Katli Yeralti Destani (Final Surum)             ║");
            Console.WriteLine("  ╚════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();

            YavasYaz("\nYuzyillar suren uykusundan uyanan KADIM EJDERHA MALAKOR, 25. katta", ConsoleColor.Gray, 10);
            YavasYaz("zindanin tum kapilarini muhurledi. Hayatta kalmak ve efsaneye donusmek", ConsoleColor.Gray, 10);
            YavasYaz("icin 5 yoldasini bul, silahlarini kusan ve kaderini belirle!", ConsoleColor.Gray, 10);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("\n> Savascinin adini gir: ");
            Console.ResetColor();
            string girilenAd = (Console.ReadLine() ?? "").Trim();
            if (girilenAd.Length > 0)
            {
                oyuncuAdi = girilenAd;
            }

            YavasYaz("\n[MÜHÜR AKTİF]: Hos geldin " + oyuncuAdi + "! Fail-Safe Ejderha Kalkani devrede.", ConsoleColor.Green, 10);
            Bekle();
        }

        // --- DINAMIK TEMA SECICI ---
        static void TemaGuncelle(int kat)
        {
            if (kat == 25)
            {
                temaRengi = ConsoleColor.Red;
            }
            else if (kat % 5 == 0)
            {
                temaRengi = ConsoleColor.DarkRed;
            }
            else if (kat >= 16)
            {
                temaRengi = ConsoleColor.DarkYellow;
            }
            else if (kat >= 8)
            {
                temaRengi = ConsoleColor.DarkCyan;
            }
            else
            {
                temaRengi = ConsoleColor.DarkMagenta;
            }
        }

        // --- GELISMIS UI & HUD TASARIMI ---
        static void HudCiz()
        {
            EkranTemizle();
            Console.ForegroundColor = temaRengi;
            Console.WriteLine("╔════════════════════════════════════════════════════════════════════════╗");
            Console.ResetColor();

            Console.Write("║ CAN: ");
            Console.ForegroundColor = can > 40 ? ConsoleColor.Green : ConsoleColor.Red;
            double canOrani = (double)can / maksCan;
            int doluBar = (int)Math.Ceiling(canOrani * 10);
            if (doluBar < 0) doluBar = 0;
            if (doluBar > 10) doluBar = 10;

            Console.Write("[");
            for (int i = 0; i < 10; i++)
            {
                if (i < doluBar) Console.Write("█");
                else Console.Write("░");
            }
            Console.Write("] " + can + "/" + maksCan + " ");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("│ ALTIN: " + altin + " ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("│ IKSIR: " + iksirSayisi + " ");
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("│ KAT: " + mevcutKat + "/25");
            Console.ResetColor();

            int toplamMin = silahMinHasar + kostumEkstraHasar;
            int toplamMax = silahMaxHasar + kostumEkstraHasar;
            Console.Write("║ SILAH: ");
            Console.ForegroundColor = silahNadirlik == "Mistik" ? ConsoleColor.Magenta : ConsoleColor.White;
            Console.Write(silahAdi + " [" + silahNadirlik + "] (" + toplamMin + "-" + toplamMax + ")");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(" │ KOSTUM: " + kostumAdi + " (+" + kostumTurBasiCan + " Can/Tur)");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.Write("║ EKIP : ");
            if (sadikKatildi) Console.Write("[Sadik Pekka] ");
            if (nehirKatildi) Console.Write("[Nehir Cokcok] ");
            if (emreKatildi) Console.Write("[Emre Belezoglu] ");
            if (denizKatildi) Console.Write("[Deniz Akdeniz] ");
            if (alperenKatildi) Console.Write("[Alperen Basiyarik] ");
            if (!sadikKatildi && !nehirKatildi && !emreKatildi && !denizKatildi && !alperenKatildi)
            {
                Console.Write("Henuz ekibe katilan yoldas yok.");
            }
            Console.WriteLine();

            string kalkanDurumu = failSafeAktif ? "AKTIF (1 olumcul darbe engeller)" : "KULLANILDI";
            Console.ForegroundColor = temaRengi;
            Console.WriteLine("║ BOLGE: " + bolumAdi.ToUpperInvariant() + " │ FAIL-SAFE: " + kalkanDurumu);
            Console.WriteLine("╚════════════════════════════════════════════════════════════════════════╝\n");
            Console.ResetColor();
        }

        // --- HAFTA 7: IC ICE FOR DONGUSU ILE 5x5 ZINDAN IZGARASI ---
        static void ZindanIzgarasiCiz()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("┌─────────── 5x5 ZINDAN HARITASI ([P]: Sen, [B]: Boss, [X]: Gecildi) ───────────┐");
            int sayac = 1;
            for (int satir = 0; satir < 5; satir++)
            {
                Console.Write("   ");
                for (int sutun = 0; sutun < 5; sutun++)
                {
                    if (sayac == mevcutKat)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.Write("[P] ");
                    }
                    else if (sayac == 25)
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.Write("[D] ");
                    }
                    else if (sayac % 5 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("[B] ");
                    }
                    else if (sayac < mevcutKat)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkGray;
                        Console.Write("[X] ");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write("[.] ");
                    }
                    sayac++;
                }
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("└──────────────────────────────────────────────────────────────────────────────┘\n");
            Console.ResetColor();
        }

        // --- HAFTA 5 & 6: SWITCH-CASE, DO-WHILE, BREAK & CONTINUE ---
        static int SecimAl(string s1, string s2, string s3, bool disMenuAktif = true)
        {
            int sonuc;
            bool gecerliSecim = false;

            do
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(" [1] " + s1);
                Console.WriteLine(" [2] " + s2);
                Console.WriteLine(" [3] " + s3);
                if (disMenuAktif)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" [4] Yoldaslarla Konus & Tavsiye Al");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine(" [5] Envanter, Kostum Degistir & Iksir Ic");
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    Console.WriteLine(" [6] Zindan Haritasini Gor (5x5 Izgara)");
                }
                Console.ResetColor();

                Console.Write("\n> Seciminiz: ");
                string giris = (Console.ReadLine() ?? "").Trim();

                if (!int.TryParse(giris, out sonuc))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Lutfen sadece rakam giriniz!\n");
                    Console.ResetColor();
                    continue; // Hafta 6: Hatali giriste dongu basina don
                }

                switch (sonuc)
                {
                    case 1:
                    case 2:
                    case 3:
                        gecerliSecim = true;
                        break; // Hafta 5 & 6: Secim onaylandi, switch'ten cik
                    case 4:
                        if (disMenuAktif)
                        {
                            YoldasSohbetMenusu();
                            HudCiz();
                        }
                        else
                        {
                            Console.WriteLine("Savas sirasinda sohbet edemezsin!\n");
                        }
                        break;
                    case 5:
                        if (disMenuAktif)
                        {
                            EnvanterMenusu();
                            HudCiz();
                        }
                        else
                        {
                            Console.WriteLine("Savas sirasinda envanteri acamazsin!\n");
                        }
                        break;
                    case 6:
                        if (disMenuAktif)
                        {
                            HudCiz();
                            ZindanIzgarasiCiz();
                        }
                        else
                        {
                            Console.WriteLine("Savas sirasinda haritaya bakamazsin!\n");
                        }
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Gecersiz secenek! Tekrar deneyin.\n");
                        Console.ResetColor();
                        break;
                }
            } while (!gecerliSecim);

            return sonuc;
        }

        // --- ENVANTER VE KOSTUM DEGISTIRME MENUSU ---
        static void EnvanterMenusu()
        {
            HudCiz();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("╔════════════════════ ENVANTER & KOSTUM DOLABI ════════════════════╗");
            Console.ResetColor();
            Console.WriteLine("  Aktif Silah    : " + silahAdi + " [" + silahNadirlik + "] (" + silahMinHasar + "-" + silahMaxHasar + " Hasar)");
            Console.WriteLine("  Aktif Kostum   : " + kostumAdi + " (+" + kostumTurBasiCan + " Can/Tur, +" + kostumEkstraHasar + " Hasar)");
            Console.WriteLine("  Can Iksiri     : " + iksirSayisi + " adet (+45 Can yeniler)");
            Console.WriteLine("  Sevilen Hayvan : " + sevilenHayvan + "\n");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" [1] Can Iksiri Ic (+45 Can)");
            if (sifaciYelekVar) Console.WriteLine(" [2] Kostum Giy: Sifaci Deri Yelek (+5 Can/Tur, +2 Hasar)");
            if (celikZirhVar) Console.WriteLine(" [3] Kostum Giy: Celik Muhafiz Zirhi (+7 Can/Tur, +5 Hasar)");
            if (kurtPeleriniVar) Console.WriteLine(" [4] Kostum Giy: Kurt Ruhu Pelerini (+9 Can/Tur, +7 Hasar)");
            if (ejderZirhiVar) Console.WriteLine(" [5] Kostum Giy: Kadim Ejder Zirhi (+14 Can/Tur, +12 Hasar)");
            Console.WriteLine(" [0] Geri Don");
            Console.ResetColor();

            Console.Write("\n> Islem secin: ");
            string sec = (Console.ReadLine() ?? "").Trim();

            if (sec == "1")
            {
                if (iksirSayisi > 0 && can < maksCan)
                {
                    iksirSayisi--;
                    can = Math.Min(maksCan, can + 45);
                    YavasYaz("Can iksiri ictin! Canin yenilendi: " + can + "/" + maksCan, ConsoleColor.Green);
                }
                else if (iksirSayisi <= 0)
                {
                    YavasYaz("Cantanda iksir kalmamis!", ConsoleColor.Red);
                }
                else
                {
                    YavasYaz("Canin zaten tamamen dolu!", ConsoleColor.Yellow);
                }
                Bekle();
            }
            else if (sec == "2" && sifaciYelekVar)
            {
                kostumAdi = "Sifaci Deri Yelek";
                kostumTurBasiCan = 5;
                kostumEkstraHasar = 2;
                YavasYaz("Sifaci Deri Yelek giyildi!", ConsoleColor.Cyan);
                Bekle();
            }
            else if (sec == "3" && celikZirhVar)
            {
                kostumAdi = "Celik Muhafiz Zirhi";
                kostumTurBasiCan = 7;
                kostumEkstraHasar = 5;
                YavasYaz("Celik Muhafiz Zirhi giyildi!", ConsoleColor.Cyan);
                Bekle();
            }
            else if (sec == "4" && kurtPeleriniVar)
            {
                kostumAdi = "Kurt Ruhu Pelerini";
                kostumTurBasiCan = 9;
                kostumEkstraHasar = 7;
                YavasYaz("Kurt Ruhu Pelerini giyildi!", ConsoleColor.Magenta);
                Bekle();
            }
            else if (sec == "5" && ejderZirhiVar)
            {
                kostumAdi = "Kadim Ejder Zirhi";
                kostumTurBasiCan = 14;
                kostumEkstraHasar = 12;
                YavasYaz("Kadim Ejder Zirhi giyildi!", ConsoleColor.Yellow);
                Bekle();
            }
        }

        // --- 5 YOLDAS ILE DIYALOG, HAYAT TAVSIYESI, HEDIYE VE %30 EASTER EGG ---
        static void YoldasSohbetMenusu()
        {
            HudCiz();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("╔══════════════════ ZINDAN YOLDASLARI & DIYALOG ══════════════════╗");
            Console.ResetColor();

            if (!sadikKatildi && !nehirKatildi && !emreKatildi && !denizKatildi && !alperenKatildi)
            {
                Console.WriteLine("Henuz ekibine katilan kimse yok. Katlarda ilerleyerek onlari bulabilirsin.");
                Bekle();
                return;
            }

            if (sadikKatildi) Console.WriteLine(" [1] Sadik Pekka (Agir Zirhli Ezici)");
            if (nehirKatildi) Console.WriteLine(" [2] Nehir Cokcok (Sifaci Simyaci)");
            if (emreKatildi) Console.WriteLine(" [3] Emre Belezoglu (Taktiksel Oyun Kurucu)");
            if (denizKatildi) Console.WriteLine(" [4] Deniz Akdeniz (Dalga Kalkan Ustasi)");
            if (alperenKatildi) Console.WriteLine(" [5] Alperen Basiyarik (Golge Suikastci)");
            Console.WriteLine(" [0] Geri Don");

            Console.Write("\nKiminle konusmak istersin?: ");
            string sec = (Console.ReadLine() ?? "").Trim();

            string secilenIsim;
            string tavsiye;

            if (sec == "1" && sadikKatildi)
            {
                secilenIsim = "Sadik Pekka";
                tavsiye = "Kalkanin kirilsa bile durusun bozulmasin; sabir en sert celikten saglamdir.";
            }
            else if (sec == "2" && nehirKatildi)
            {
                secilenIsim = "Nehir Cokcok";
                tavsiye = "Baskalarinin yaralarini sararken kendini ihmal etme, once sen ayakta kalmalisin.";
            }
            else if (sec == "3" && emreKatildi)
            {
                secilenIsim = "Emre Belezoglu";
                tavsiye = "Oyunu sadece kosanlar degil, bir sonraki hamleyi onceden gorenler kazanir.";
            }
            else if (sec == "4" && denizKatildi)
            {
                secilenIsim = "Deniz Akdeniz";
                tavsiye = "Firtinaya karsi kurek cekmek yerine ruzgarin yonunu kullanmayi ogren.";
            }
            else if (sec == "5" && alperenKatildi)
            {
                secilenIsim = "Alperen Basiyarik";
                tavsiye = "Karanliktan korkma; dogru ani beklersen golgeler bile sana yol acar.";
            }
            else
            {
                return;
            }

            HudCiz();
            YavasYaz(secilenIsim + ": 'Kadim Ejderha yaklasiyor " + oyuncuAdi + ", ne konusmak istersin?'", ConsoleColor.Cyan);

            int easterZar = rnd.Next(1, 101);
            if (easterZar <= 30)
            {
                YavasYaz(secilenIsim + " (fisildayarak): 'Bu arada unutmadan: gelistiriciyi takip et INSTAGRAM: alpr._.gndz06'", ConsoleColor.Magenta);
            }

            Console.WriteLine("\n [1] 'Bana biraz hayat tavsiyesi verir misin?'");
            Console.WriteLine(" [2] 'Sana guveniyorum, bu zindandan birlikte cikacagiz.'");
            Console.Write("> Cevabin: ");
            string tepki = (Console.ReadLine() ?? "").Trim();

            if (tepki == "1")
            {
                YavasYaz("\n" + secilenIsim + ": '" + tavsiye + "'", ConsoleColor.Yellow);
                iksirSayisi++;
                YavasYaz("-> Bu guzel sohbetin ardindan sana 1 Can Iksiri hediye etti!", ConsoleColor.Green);
            }
            else
            {
                YavasYaz("\n" + secilenIsim + ": 'Bu sozlerin moralimi yukseltti! Al bu altinlar isine yarar.'", ConsoleColor.Cyan);
                altin += 15;
                YavasYaz("-> Sana 15 Altin verdi!", ConsoleColor.Yellow);
            }
            Bekle();
        }

        // --- HAFTA 6: GAME LOOP MIMARISI, RANDOM D20 ZARI, BREAK & FAIL-SAFE KALKANI ---
        static bool SavasMotoru(string dusmanAdi, int dusmanCan, int dusmanMin, int dusmanMax, bool bossMu)
        {
            int dusmanMaksCan = dusmanCan;
            bool suKalkani = false;
            int bonusKritik = 0;

            YavasYaz("\n[SAVAS BASLADI] Karsinda: " + dusmanAdi + "!", ConsoleColor.Red);
            Bekle();

            while (can > 0 && dusmanCan > 0)
            {
                HudCiz();

                if (kostumTurBasiCan > 0 && can < maksCan)
                {
                    can = Math.Min(maksCan, can + kostumTurBasiCan);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("[KOSTUM PASIFI]: " + kostumAdi + " +" + kostumTurBasiCan + " can doldurdu!");
                    Console.ResetColor();
                }

                Console.ForegroundColor = bossMu ? ConsoleColor.Red : ConsoleColor.DarkYellow;
                Console.WriteLine("DUSMAN: " + dusmanAdi + " | CAN: " + dusmanCan + "/" + dusmanMaksCan + "\n");
                Console.ResetColor();

                int hamle = SecimAl(
                    "Saldir (d20 Zari At)",
                    "Savunma Pozisyonu Al (Hasari azaltir)",
                    "Can Iksiri Ic veya Yoldas Cagir",
                    false
                );

                bool savunmaPozisyonu = false;

                if (hamle == 1)
                {
                    int d20 = rnd.Next(1, 21);
                    int temelHasar = rnd.Next(silahMinHasar, silahMaxHasar + 1) + kostumEkstraHasar;
                    Console.WriteLine("\n[d20 ZARI]: " + d20 + " geldi!");

                    if (d20 == 1)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Kritik Iskalama! Ayagin kaydi ve hasar veremedin.");
                        Console.ResetColor();
                    }
                    else if (d20 + bonusKritik >= 18)
                    {
                        int kritikHasar = (int)(temelHasar * kritikCarpan);
                        dusmanCan -= kritikHasar;
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("MUKEMMEL KRITIK VURUS! Dusmana " + kritikHasar + " hasar vurdun!");
                        Console.ResetColor();
                    }
                    else
                    {
                        dusmanCan -= temelHasar;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("Dusmana " + temelHasar + " hasar verdin.");
                        Console.ResetColor();
                    }
                    bonusKritik = 0;
                }
                else if (hamle == 2)
                {
                    savunmaPozisyonu = true;
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\nGardini aldin! Gelecek saldirinin hasari yariya dusecek.");
                    Console.ResetColor();
                }
                else if (hamle == 3)
                {
                    Console.WriteLine("\n [1] Can Iksiri Ic (+45 Can)");
                    Console.WriteLine(" [2] Yoldasini Savasa Cagir");
                    Console.Write("> Secim: ");
                    string altSecim = (Console.ReadLine() ?? "").Trim();

                    if (altSecim == "2")
                    {
                        YoldasSavasaKatil(ref dusmanCan, ref suKalkani, ref bonusKritik);
                    }
                    else
                    {
                        if (iksirSayisi > 0)
                        {
                            iksirSayisi--;
                            can = Math.Min(maksCan, can + 45);
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Can iksiri ictin! +45 Can yenilendi.");
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Cantanda iksir kalmamis!");
                            Console.ResetColor();
                        }
                    }
                }

                if (dusmanCan <= 0)
                {
                    int kazanilanAltin = bossMu ? (35 + mevcutKat * 2) : (10 + mevcutKat);
                    altin += kazanilanAltin;
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("\n" + dusmanAdi + " yenildi! +" + kazanilanAltin + " Altin kazandin.");
                    Console.ResetColor();
                    GanimetDusur(bossMu);
                    Bekle();
                    break; // Hafta 6: Dusman yenildiginde while dongusunden break ile cik
                }

                int dusmanHasar = rnd.Next(dusmanMin, dusmanMax + 1);
                if (savunmaPozisyonu) dusmanHasar /= 2;
                if (suKalkani)
                {
                    dusmanHasar /= 3;
                    suKalkani = false;
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Deniz Akdeniz'in Su Kalkani darbenin buyuk kismini emdi!");
                    Console.ResetColor();
                }

                can -= dusmanHasar;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(dusmanAdi + " saldirdi ve " + dusmanHasar + " hasar verdi!");
                Console.ResetColor();

                if (can <= 0 && failSafeAktif)
                {
                    failSafeAktif = false;
                    can = 25;
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("\n[FAIL-SAFE KALKANI DEVREDE]: Olumcul darbeden son anda kurtuldun! Canin 25'e sabitlendi!");
                    Console.ResetColor();
                }

                Bekle();
            }

            return can > 0;
        }

        static void YoldasSavasaKatil(ref int dusmanCan, ref bool suKalkani, ref int bonusKritik)
        {
            if (!sadikKatildi && !nehirKatildi && !emreKatildi && !denizKatildi && !alperenKatildi)
            {
                Console.WriteLine("Cagirabilecegin hic yoldasin yok!");
                return;
            }

            Console.WriteLine("\nKimi savasa cagiriyorsun?");
            if (sadikKatildi) Console.WriteLine(" [1] Sadik Pekka (Agir Zirhli Darbe)");
            if (nehirKatildi) Console.WriteLine(" [2] Nehir Cokcok (Sifa Iksiri Yagmuru)");
            if (emreKatildi) Console.WriteLine(" [3] Emre Belezoglu (Taktiksel Pas & Kritik)");
            if (denizKatildi) Console.WriteLine(" [4] Deniz Akdeniz (Dalga Kalkani)");
            if (alperenKatildi) Console.WriteLine(" [5] Alperen Basiyarik (Golge Kombo)");
            Console.Write("> Secim: ");
            string sec = (Console.ReadLine() ?? "").Trim();

            int gucOlcegi = 18 + (mevcutKat * 2);
            Console.ForegroundColor = ConsoleColor.Cyan;

            if (sec == "1" && sadikKatildi)
            {
                int hasar = gucOlcegi + 10;
                dusmanCan -= hasar;
                Console.WriteLine("Sadik Pekka dev baltasiyla yeri sarsti ve dusmana " + hasar + " agir hasar vurdu!");
            }
            else if (sec == "2" && nehirKatildi)
            {
                int sifa = gucOlcegi + 15;
                can = Math.Min(maksCan, can + sifa);
                Console.WriteLine("Nehir Cokcok sifali iksir firlatti ve sana +" + sifa + " Can basti!");
            }
            else if (sec == "3" && emreKatildi)
            {
                dusmanCan -= gucOlcegi;
                bonusKritik = 8;
                Console.WriteLine("Emre Belezoglu dusmana " + gucOlcegi + " hasar vurdu ve sonraki d20 zarina +8 kritik avantaji verdi!");
            }
            else if (sec == "4" && denizKatildi)
            {
                dusmanCan -= gucOlcegi;
                suKalkani = true;
                Console.WriteLine("Deniz Akdeniz " + gucOlcegi + " dalga hasari vurdu ve etrafina Su Kalkani ordu!");
            }
            else if (sec == "5" && alperenKatildi)
            {
                int v1 = gucOlcegi / 2 + 4;
                int v2 = gucOlcegi / 2 + 6;
                dusmanCan -= (v1 + v2);
                Console.WriteLine("Alperen Basiyarik golgelerden iki kez saldirdi: " + v1 + " + " + v2 + " kombo hasar!");
            }
            else
            {
                Console.WriteLine("Bu yoldas henuz ekibinde degil!");
            }
            Console.ResetColor();
        }

        // --- DUSUK IHTIMALLI ITEM VE 3 MISTIK SILAH DUSURME ---
        static void GanimetDusur(bool bossMu)
        {
            int sans = rnd.Next(1, 101);
            int mistikLimit = bossMu ? 18 : 6;

            if (sans <= mistikLimit)
            {
                if (!mistik1Dustu)
                {
                    mistik1Dustu = true;
                    SilahKusandir("Kaosun Kizil Tirpani", "Mistik", 42, 60, 2.0f);
                }
                else if (!mistik2Dustu)
                {
                    mistik2Dustu = true;
                    SilahKusandir("Yildiz Yaran Ejder Kilici", "Mistik", 46, 65, 2.1f);
                }
                else if (!mistik3Dustu)
                {
                    mistik3Dustu = true;
                    SilahKusandir("Zaman Buken Ruh Hanceri", "Mistik", 40, 56, 2.3f);
                }
            }
            else if (sans <= 25)
            {
                iksirSayisi++;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("-> Dusmandan nadir bir Can Iksiri dustu!");
                Console.ResetColor();
            }
        }

        static void SilahKusandir(string ad, string nadirlik, int min, int max, float kritik)
        {
            silahAdi = ad;
            silahNadirlik = nadirlik;
            silahMinHasar = min;
            silahMaxHasar = max;
            kritikCarpan = kritik;

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n[YENI SILAH KUSANILDI]: " + ad + " [" + nadirlik + "] (" + min + "-" + max + " Hasar)");
            Console.ResetColor();
        }

        static void KostumKusandir(string ad, int turCan, int ekstraHasar, int maksCanBonusu)
        {
            kostumAdi = ad;
            kostumTurBasiCan = turCan;
            kostumEkstraHasar = ekstraHasar;
            maksCan += maksCanBonusu;
            can += maksCanBonusu;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n[YENI KOSTUM GIYILDI]: " + ad + " (+" + turCan + " Can/Tur, +" + ekstraHasar + " Hasar, +" + maksCanBonusu + " Maks Can)");
            Console.ResetColor();
        }

        static void HayvanSev(string hayvanAdi, string tepki)
        {
            sevilenHayvan++;
            can = Math.Min(maksCan, can + 20);
            Console.ForegroundColor = ConsoleColor.Green;
            YavasYaz("\n" + hayvanAdi + " basini oksatti: " + tepki + " (+20 Can)", ConsoleColor.Green);

            if (sevilenHayvan == 2)
            {
                kurtPeleriniVar = true;
                YavasYaz("[GIZLI EASTER EGG]: Hayvan dostu ruhun uyandi! Gizli bir kostum buldun!", ConsoleColor.Magenta);
                KostumKusandir("Kurt Ruhu Pelerini", 9, 7, 25);
            }
            Console.ResetColor();
        }

        // --- 25 BOLUMLUK ZINDAN SENARYOSU ---
        static void BolumYoneticisi(int kat)
        {
            if (kat == 1)
            {
                bolumAdi = "Karanlik Hucreler";
                HudCiz();
                YavasYaz("Hucrenin yan bolmesinde dev zirhli Sadik Pekka parmakliklari zorluyor.");
                YavasYaz("Kosede ise minik bir zindan kedisi titriyor.");
                int s = SecimAl("Sadik Pekka ile isbirligi yap ve kapiyi kirin", "Kosedeki minik kediyi sev", "Gardiyani pusuya dusur");
                if (s == 1 || s == 2)
                {
                    if (s == 2) HayvanSev("Minik Zindan Kedisi", "Miyavlayip patisiyle pasli anahtari itti!");
                    sadikKatildi = true;
                    YavasYaz("Sadik Pekka ekibine katildi!", ConsoleColor.Green);
                    SilahKusandir("Pasli Kisa Kilic", "Siradan", 10, 15, 1.5f);
                }
                else SavasMotoru("Hucre Gardiyani", 36, 5, 9, false);
            }
            else if (kat == 3)
            {
                bolumAdi = "Eski Simya Odasi";
                HudCiz();
                YavasYaz("Kirik iksir siselerinin arasinda Nehir Cokcok yarali bir yarasa ile ilgileniyor.");
                int s = SecimAl("Nehir Cokcok'u ekibe davet et", "Yarali yarasayi sev", "Masadaki iksirleri topla");
                if (s == 1 || s == 2)
                {
                    if (s == 2) HayvanSev("Magara Yarasasi", "Kanat cirpip omzuna kondu!");
                    nehirKatildi = true;
                    sifaciYelekVar = true;
                    YavasYaz("Nehir Cokcok ekibine katildi!", ConsoleColor.Green);
                    KostumKusandir("Sifaci Deri Yelek", 5, 2, 15);
                }
                else { iksirSayisi += 2; YavasYaz("+2 Can Iksiri buldun!", ConsoleColor.Cyan); }
            }
            else if (kat == 6)
            {
                bolumAdi = "Taktik Odasi";
                HudCiz();
                YavasYaz("Savas haritalarinin basinda Emre Belezoglu zindan planlarini inceliyor.");
                int s = SecimAl("Emre Belezoglu ile tanis ve ekibe al", "Gizli hazine haritasini takip et", "Oda muhafizina saldir");
                if (s == 1 || s == 2)
                {
                    emreKatildi = true;
                    altin += 25;
                    YavasYaz("Emre Belezoglu ekibine katildi ve +25 Altin buldunuz!", ConsoleColor.Cyan);
                    SilahKusandir("Keskin Sovalye Kilici", "Nadir", 16, 24, 1.7f);
                }
                else SavasMotoru("Harita Muhafizi", 60, 8, 13, false);
            }
            else if (kat == 8)
            {
                bolumAdi = "Yeralti Sarnici";
                HudCiz();
                YavasYaz("Yeralti suyunun kenarinda Deniz Akdeniz ve sevimli bir su samuru var.");
                int s = SecimAl("Deniz Akdeniz'i ekibe davet et", "Su samurunu sev", "Sarnic canavarina saldir");
                if (s == 1 || s == 2)
                {
                    if (s == 2) HayvanSev("Yeralti Su Samuru", "Suyun icinde takla atip parlayan bir inci getirdi!");
                    denizKatildi = true;
                    YavasYaz("Deniz Akdeniz ekibine katildi!", ConsoleColor.Cyan);
                    SilahKusandir("Dalga Kesen Mizrak", "Nadir", 19, 28, 1.8f);
                }
                else SavasMotoru("Sarnic Hydrasi", 72, 9, 15, false);
            }
            else if (kat == 9)
            {
                bolumAdi = "Fisildayan Tuneller";
                HudCiz();
                YavasYaz("Golgelerin arasindan Alperen Basiyarik sessizce beliriyor.");
                int s = SecimAl("Alperen Basiyarik'i ekibe al", "Golge suikastcilarina pusu kur", "Tunelden sessizce gec");
                if (s == 1 || s == 2)
                {
                    alperenKatildi = true;
                    YavasYaz("Alperen Basiyarik ekibine katildi! 5 kisilik ekip tamamlandi!", ConsoleColor.Magenta);
                    SilahKusandir("Gece Golgesi Hanceri", "Nadir", 21, 30, 1.9f);
                }
                else { altin += 20; YavasYaz("+20 Altin buldun.", ConsoleColor.Yellow); }
            }
            else if (kat == 5 || kat == 10 || kat == 15 || kat == 20)
            {
                bolumAdi = "Kat " + kat + " Ejder Muhafizi (ARA BOSS)";
                HudCiz();
                YavasYaz("Kat " + kat + " cikisini koruyan dev Ara Boss yolunu kesiyor!", ConsoleColor.Red);
                bool kazandi = SavasMotoru("Kat " + kat + " Ejder Muhafizi", 60 + (kat * 6), 8 + (kat / 3), 13 + (kat / 2), true);
                if (kazandi && kat == 10)
                {
                    celikZirhVar = true;
                    KostumKusandir("Celik Muhafiz Zirhi", 7, 5, 25);
                }
                else if (kazandi && kat == 15)
                {
                    SilahKusandir("Anka Alevi Kilici", "Efsanevi", 29, 41, 2.0f);
                }
                else if (kazandi && kat == 20)
                {
                    ejderZirhiVar = true;
                    KostumKusandir("Kadim Ejder Zirhi", 14, 12, 40);
                }
            }
            else if (kat == 25)
            {
                bolumAdi = "Kadim Ejderha Tahti (FINAL)";
                HudCiz();
                YavasYaz("25. KAT! Alevlerin icinden KADIM EJDERHA MALAKOR yukseliyor!", ConsoleColor.Red);
                YavasYaz("Ejderhanin gogsunde kirik bir kadim muhur tasi parildiyor...\n", ConsoleColor.Yellow);

                int finalSecim = SecimAl(
                    "Kilicini cek ve Kadim Ejderha Malakor ile savas!",
                    "Kadim Muhur Tasini onar ve ejderhayla bariscil anlasma yap",
                    "Yoldaslarinla birlikte son bir saldiri duzenle"
                );

                if (finalSecim == 2)
                {
                    ejderhaIleAnlasildi = true;
                    YavasYaz("\nMuhur tasina dokundun! Kadim Ejderha ofkesini dindirip onunde egildi...", ConsoleColor.Cyan);
                    Bekle();
                }
                else
                {
                    SavasMotoru("Kadim Ejderha Malakor", 225, 16, 26, true);
                }
            }
            else
            {
                bolumAdi = "Ejderha Zindani Kati " + kat;
                HudCiz();
                if (kat % 2 == 0)
                {
                    YavasYaz("Kat " + kat + " koridorunda ejderha tarikatindan bir muhafiz devriye geziyor!");
                    int s = SecimAl("Saldiriya gec", "Tuzak kur (-10 Altin, dusman canini azaltir)", "Yoldaslarla moral depola (+15 Can)");
                    int dCan = 40 + (kat * 4);
                    if (s == 2 && altin >= 10) { altin -= 10; dCan -= 20; }
                    else if (s == 3) { can = Math.Min(maksCan, can + 15); }
                    SavasMotoru("Ejder Tarikati Savascisi (Kat " + kat + ")", dCan, 6 + (kat / 4), 11 + (kat / 3), false);
                }
                else
                {
                    YavasYaz("Bu katta gezgin bir simyaci tuccar ve dinlenme sunagi var.");
                    int s = SecimAl("Can Iksiri Satin Al (20 Altin)", "Maksimum Cani +15 Artir (35 Altin)", "Sunakta ucretsiz dinlen (+25 Can)");
                    if (s == 1 && altin >= 20) { altin -= 20; iksirSayisi++; YavasYaz("+1 Can Iksiri alindi!", ConsoleColor.Green); }
                    else if (s == 2 && altin >= 35) { altin -= 35; maksCan += 15; can += 15; YavasYaz("+15 Maks Can kazanildi!", ConsoleColor.Cyan); }
                    else { can = Math.Min(maksCan, can + 25); YavasYaz("+25 Can yenilendi.", ConsoleColor.Green); }
                }
            }

            if (can > 0 && kat != 5 && kat != 10 && kat != 15 && kat != 20 && kat != 25)
            {
                Bekle();
            }
        }

        // --- 5 FARKLI SON EKRANI ---
        static void OyunSonuEkrani()
        {
            HudCiz();
            int ekipSayisi = 0;
            if (sadikKatildi) ekipSayisi++;
            if (nehirKatildi) ekipSayisi++;
            if (emreKatildi) ekipSayisi++;
            if (denizKatildi) ekipSayisi++;
            if (alperenKatildi) ekipSayisi++;

            bool mistikVar = (silahNadirlik == "Mistik");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("╔════════════════════════════════════════════════════════════════════════╗");

            if (ejderhaIleAnlasildi)
            {
                Console.WriteLine("║          SON 1 (KADİM ANLAŞMA SONU): EJDERHA SÜVARİSİ                  ║");
                Console.WriteLine("╚════════════════════════════════════════════════════════════════════════╝\n");
                Console.ResetColor();
                YavasYaz("Kadim Ejderha Malakor ile savasmak yerine muhru onararak barisi sectin!", ConsoleColor.Cyan);
                YavasYaz("Artik gokyuzunun en kadim ejderhasi senin sadik dostun ve koruyucun!", ConsoleColor.Yellow);
            }
            else if (mistikVar && ekipSayisi == 5)
            {
                Console.WriteLine("║          SON 2 (GİZLİ EFSANEVİ SON): KADİM EJDERHA EFENDİSİ            ║");
                Console.WriteLine("╚════════════════════════════════════════════════════════════════════════╝\n");
                Console.ResetColor();
                YavasYaz("Mistik silahin gucu ve 5 yoldasinin sarsilmaz destegiyle Kadim Ejderha'yi", ConsoleColor.Magenta);
                YavasYaz("dize getirdin! Artik tum diyarlarin en buyuk efsanesisin!", ConsoleColor.Yellow);
            }
            else if (ekipSayisi >= 4)
            {
                Console.WriteLine("║          SON 3 (GERÇEK KARDEŞLİK SONU): ÖZGÜRLÜK ŞAFAĞI                ║");
                Console.WriteLine("╚════════════════════════════════════════════════════════════════════════╝\n");
                Console.ResetColor();
                YavasYaz("25. katin demir kapilari acildi; tum yoldaslarinla ozgurluge kavustun!", ConsoleColor.Green);
            }
            else if (sevilenHayvan >= 2)
            {
                Console.WriteLine("║          SON 4 (DOĞANIN KORUYUCUSU SONU): VAHŞİ RUH                    ║");
                Console.WriteLine("╚════════════════════════════════════════════════════════════════════════╝\n");
                Console.ResetColor();
                YavasYaz("Hayvanlara gosterdigin merhamet sana ormanin yolunu acti ve kurtuldun!", ConsoleColor.Cyan);
            }
            else
            {
                Console.WriteLine("║          SON 5 (YALNIZ KURT SONU): BEDELİ ÖDENMİŞ KAÇIŞ                ║");
                Console.WriteLine("╚════════════════════════════════════════════════════════════════════════╝\n");
                Console.ResetColor();
                YavasYaz("Tek basina verdigin 25 katlik mucadele sonunda zindandan kacmayi basardin!", ConsoleColor.Gray);
            }

            Console.WriteLine("\n--- MACERA OZETI (ALPER.EXE) ---");
            Console.WriteLine("Kahraman: " + oyuncuAdi + " | Kalan Can: " + can + "/" + maksCan + " | Altin: " + altin);
            Console.WriteLine("Ekip: " + ekipSayisi + "/5 | Sevilen Hayvan: " + sevilenHayvan + " | Son Silah: " + silahAdi + " [" + silahNadirlik + "]");
            Bekle();
        }

        static void OlumEkrani()
        {
            EkranTemizle();
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("╔════════════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║                            MACERA SONA ERDI                            ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════════════╝");
            Console.ResetColor();
            YavasYaz(oyuncuAdi + ", " + mevcutKat + ". katta Kadim Ejderha'nin ordusuna yenik dustun.", ConsoleColor.Red);
            Bekle();
        }

        static void EkranTemizle()
        {
            try { Console.Clear(); }
            catch (Exception) { }
        }

        static void Bekle()
        {
            Console.WriteLine("\nDevam etmek icin bir tusa bas...");
            try { Console.ReadKey(true); }
            catch { }
        }

        static void YavasYaz(string metin, ConsoleColor renk = ConsoleColor.White, int hiz = 6)
        {
            Console.ForegroundColor = renk;
            foreach (char c in metin)
            {
                Console.Write(c);
                if (hiz > 0) Thread.Sleep(hiz);
            }
            Console.WriteLine();
            Console.ResetColor();
        }
    }
}   